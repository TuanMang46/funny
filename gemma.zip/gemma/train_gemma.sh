case $1 in
    "1_GPU_4_BIT")
        echo "Training with single GPU with 4-bit quantization"
        CUDA_VISIBLE_DEVICES=1 python3 train_mistral.py \
                    --fourbit \
                    --lora \
                    --lora_rank 32 \
                    --gradient_accumulation_steps 8 \
                    --chat_template \
                    --sliding_window 512 \
                    --data_train_path ../train_truncating2.json \
                    --data_eval_path ../eval_truncating2.json \
                    --do_eval \
                    --eval_steps 500 \
                    --evaluation_strategy steps \
                    --local_files_or_path mistral \
                    --sequence_max_length
        ;;
    "1_GPU_8_BIT")
        echo "Training with single GPU with 8-bit quantization"
        CUDA_VISIBLE_DEVICES=0 python3 train_mistral.py \
                    --eightbit \
                    --lora \
                    --lora_rank 32 \
                    --gradient_accumulation_steps 8 \
                    --chat_template \
                    --data_train_path train_truncating2.json \
                    --data_eval_path eval_truncating2.json \
                    --do_eval \
                    --eval_steps 500 \
                    --evaluation_strategy steps \
                    --local_files_or_path Open-Orca/Mistral-7B-OpenOrca
        ;;
    "2 GPUS-FSDP-FP16")
        echo "Training with multiple GPU in FSDP mode using half-precision"
        CUDA_VISIBLE_DEVICES=0,1 torchrun --nnodes 1 --nproc-per-node 2 train_mistral.py \
                    --gradient_accumulation_steps 8 \
                    --chat_template \
                    --data_train_path train_truncating2.json \
                    --data_eval_path eval_truncating2.json \
                    --do_eval \
                    --eval_steps 500 \
                    --evaluation_strategy steps \
                    --local_files_or_path Open-Orca/Mistral-7B-OpenOrca \
                    --fsdp \
                    --push_to_hub
        ;;
    "2 GPUS-FSDP-FP16-RESUME")
        echo "RESUME FROM CHECKPOINT: Training with multiple GPU in FSDP mode using half-precision"
        CUDA_VISIBLE_DEVICES=0,1 torchrun --nnodes 1 --nproc-per-node 2 train_mistral.py \
                    --gradient_accumulation_steps 8 \
                    --chat_template \
                    --data_train_path train_truncating2.json \
                    --data_eval_path eval_truncating2.json \
                    --do_eval \
                    --eval_steps 500 \
                    --evaluation_strategy steps \
                    --local_files_or_path Open-Orca/Mistral-7B-OpenOrca \
                    --fsdp \
                    --resume_from_checkpoint \
                    --checkpoint_hub kpptdll/tmp_17_11\
                    --push_to_hub
        ;;
    "2_GPU")
        echo "2 GPU FSDP Mode !!"
        LOCAL_RANK=0 CUDA_VISIBLE_DEVICES=0,1 torchrun --nnodes 1 --nproc_per_node 2 train_mistral.py \
                    --fourbit \
                    --lora \
                    --lora_rank 32 \
                    --gradient_accumulation_steps 8 \
                    --chat_template \
                    --fsdp
        ;;
    "FLASH_ATTENTION")
        echo "Using flash attention 2 !!"
        LOCAL_RANK=0 CUDA_VISIBLE_DEVICES=0,1,2 torchrun --nnodes 1 --nproc_per_node 3 train_mistral.py \
                    --flash_attention \
                    --lora \
                    --lora_rank 32 \
                    --gradient_accumulation_steps 8 \
                    --chat_template \
                    --fsdp
        ;;
    "SLIDING_WINDOW")
        echo "Custom sliding window size !!"
        LOCAL_RANK=0 CUDA_VISIBLE_DEVICES=0,1,2 torchrun --nnodes 1 --nproc_per_node 3 train_mistral.py \
                    --fourbit \
                    --lora \
                    --lora_rank 32 \
                    --gradient_accumulation_steps 8 \
                    --chat_template \
                    --fsdp \
                    --sliding_window 1024
        ;;
    "FSDP_ACCELERATE")
        echo "Training in FSDP mode with accelerate config"
        torchrun --nnodes 1 --nproc-per-node 1 train_llm.py \
                    --gradient_accumulation_steps 4 \
                    --gradient_checkpointing \
                    --data_train_path ./filter_ds_100 \
                    --local_files_or_path /tf/C4I_LLM/VinaLLaMa-2 \
                    --logging_train_steps 4 \
                    --max_length 2048 \
                    --padding max_length \
                    --seq2seq_or_causal causal \
                    --flash_attention
        ;;
    "FSDP_ACCELERATE_SEQ2SEQ")
        echo "Training in FSDP mode with accelerate config: sequence2sequence model"
        CUDA_VISIBLE_DEVICES=1,2 torchrun --nnodes 1 --nproc-per-node 2 train_fsdp_accelerate.py \
                    --gradient_accumulation_steps 4 \
                    --sliding_window 512 \
                    --gradient_checkpointing \
                    --data_train_path train_seq2seq.json \
                    --data_validation_path eval_seq2seq.json \
                    --do_eval \
                    --eval_steps 500 \
                    --evaluation_strategy steps \
                    --local_files_or_path /tf/khangld1/MultiDocumentSummarization/vit5-large \
                    --sequence_max_length \
        ;;
    *)
        echo "Not a valid argument"
        exit 1
        ;;
esac