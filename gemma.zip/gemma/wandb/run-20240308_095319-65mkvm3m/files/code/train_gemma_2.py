import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
os.environ['FSDP_OFFLOAD_PARAMS'] = "True"
os.environ['FSDP_AUTO_WRAP_POLICY'] = "TRANSFORMER_BASED_WRAP"
from transformers import (AutoTokenizer,
                          AutoModel, 
                          AutoModelForCausalLM,
                          AutoModelForSeq2SeqLM,
                          DefaultDataCollator,
                          DataCollatorForLanguageModeling,
                          DataCollatorForSeq2Seq,
                          PreTrainedTokenizerBase,
                          BitsAndBytesConfig,
                          get_scheduler,
                          MistralForCausalLM,
                          LlamaForSequenceClassification,
                          PreTrainedModel
                          )
from datasets import load_dataset
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from huggingface_hub import login
import datetime
import random
import torch
import torch.nn as nn
from accelerate import Accelerator
from accelerate.utils import set_seed
from functools import partial
from torch.utils.data import DataLoader
from torch.optim import AdamW
from bitsandbytes.optim import Adam8bit
from torchmetrics import MeanMetric
from tqdm import tqdm
from torch.distributed.fsdp.fully_sharded_data_parallel import (ShardedStateDictConfig, 
                                                                ShardedOptimStateDictConfig, 
                                                                ShardingStrategy,
                                                                StateDictType,)
from accelerate import FullyShardedDataParallelPlugin
from argparse import ArgumentParser, Namespace
from typing import Tuple, Dict, Optional, Union, Any

def format_metrics(metrics: dict, split, prefix: Optional[str] = None) -> str:
    log = f"[{split}]" + prefix
    log += " ".join([f"{key}: {value:.4f}" for key, value in metrics.items()])
    return log

def evaluate(model: PreTrainedModel, accelerator: Accelerator, eval_dataloader: DataLoader) -> MeanMetric:
    model.eval()
    val_loss = MeanMetric(nan_strategy="error").to(accelerator.device)
    with torch.no_grad():
        for batch in tqdm(eval_dataloader):
            loss = model(**batch).loss
            loss_values = accelerator.gather_for_metrics({"loss": loss.detach()})
            val_loss.update(loss_values["loss"])
    return val_loss

def test(model: PreTrainedModel, accelerator: Accelerator, test_dataloader: DataLoader) -> MeanMetric:
    model.eval()
    test_loss = MeanMetric(nan_strategy="error").to(accelerator.device)
    with torch.no_grad():
        for batch in tqdm(test_dataloader):
            loss = model(**batch).loss
            loss_values = accelerator.gather_for_metrics({"loss": loss.detach()})
            test_loss.update(loss_values["loss"])
    return test_loss

def seq2seq_tokenize(sample, tokenizer: PreTrainedTokenizerBase = None, max_length: int = 1024, padding: str = "max_length"):
    dct_pad = {"0": False, "False": False, "false": False, "1": True, "True": True, "true": True}
    if padding != "max_length":
        padding = dct_pad[padding]
        
    inputs = "summarize: " + sample['text']
    model_inputs = tokenizer(
        inputs, max_length=max_length, truncation=True, padding=padding)
    with tokenizer.as_target_tokenizer():
        labels = tokenizer(
            sample["summary"], max_length=1000, truncation=True, padding=False)
    model_inputs['labels'] = labels['input_ids']
    model_inputs['input_ids'] = model_inputs['input_ids']
    return model_inputs

def generate_and_tokenize_prompt2(sample, tokenizer: PreTrainedTokenizerBase = None, max_length: int = 1024, padding: str = "max_length") -> dict:
    dct_pad = {"0": False, "False": False, "false": False, "1": True, "True": True, "true": True}
    if padding != "max_length":
        padding = dct_pad[padding]
        
    model_input = {}
    chat = [
        {"role": "system", "content": "You are an AI assistant that follows instruction extremely well. Help as much as you can."},
        {"role": "user", "content": "Xin chào, tôi cần bạn giúp tôi một việc."},
        {"role": "assistant", "content": "Xin chào! Tôi sẵn sàng hướng dẫn bạn và giúp đỡ với việc đó. Xin vui lòng đề cập đến chi tiết về việc cần thực hiện."},
        {"role": "user", "content": "Tôi sẽ cung cấp cho bạn một văn bản và tiêu đề của nó. Sau đó, bạn hãy tóm tắt nội dung văn bản dựa trên thông tin mà tôi đã cung cấp."},
        {"role": "assistant", "content": "Xin vui lòng cho tôi thông tin về văn bản bạn muốn tóm tắt và cung cấp tiêu đề của nó."},
        {"role": "user", "content": f"Tiêu đề: {sample['title']}.\nVăn bản: {sample['content']}."},
        {"role": "assistant", "content": f"Tóm tắt văn bản: {sample['gpt_sum']}"}
    ]
    model_input['input_ids'] = tokenizer.apply_chat_template(chat, add_generation_prompt=False, max_length=max_length, padding=padding, truncation=True)
    model_input['labels'] = model_input['input_ids'].copy()
    return model_input

def generate_and_tokenize_prompt1(sample, tokenizer: PreTrainedTokenizerBase = None, max_length: int = 1024, padding: str = "max_length"):
    dct_pad = {"0": False, "False": False, "false": False, "1": True, "True": True, "true": True}
    if padding != "max_length":
        padding = dct_pad[padding]
        
    PROMPT = f"""### \"Tiêu đề\": {sample['title']}. \"Văn bản\": {sample['content']}. Tóm tắt văn bản dựa trên nội dung \"Tiêu đề\" và \"Văn bản\".\n### Bản tóm tắt: {sample['gpt_sum']}"""
    model_input = tokenizer(PROMPT, max_length=max_length, padding=padding, truncation=True)
    model_input['labels'] = model_input['input_ids'].copy()
    return model_input

def print_trainable_parameters(model: MistralForCausalLM):
    
    trainable_params = 0
    all_param = 0
    for _, param in model.named_parameters():
        all_param += param.numel()
        if param.requires_grad:
            trainable_params += param.numel()
    print(
        f"trainable params: {trainable_params} || all params: {all_param} || trainable%: {100 * trainable_params / all_param}"
    )

def freeze_layers(model: MistralForCausalLM, freeze_layers: int) -> None:
    for module in model.modules():
        for params in module.parameters():
            params.requires_grad = False
    for module in list(model.modules())[-freeze_layers:]:
        for params in module.parameters():
            params.requires_grad = True
            
def model_task(task: str = "causal") -> Tuple[AutoModel, DefaultDataCollator]:
    # If have more task in the future, need to use pattern (i.e. registry pattern) to program more explicitly
    pipeline: Dict[str, Tuple[AutoModel, DefaultDataCollator]] = {
        "causal": (AutoModelForCausalLM, DataCollatorForLanguageModeling),
        "seq2seq": (AutoModelForSeq2SeqLM, DataCollatorForSeq2Seq)
    }
    return pipeline[task]

def data_model_config(accelerator: Accelerator, parsed_args: ArgumentParser):
        
    # DATAPROCESSING    
    tokenizer_hub_or_checkpoint = parsed_args.local_files_or_path
    trust_remote_code = False
    if parsed_args.resume_from_checkpoint:
        tokenizer_hub_or_checkpoint = parsed_args.checkpoint_hub
        trust_remote_code = True
    
    # tokenizer = AutoTokenizer.from_pretrained(tokenizer_hub_or_checkpoint, padding_side="left", \
    #     add_eos_token=True, add_bos_token=True, trust_remote_code=trust_remote_code)
    tokenizer = AutoTokenizer.from_pretrained(tokenizer_hub_or_checkpoint, padding_side="left", trust_remote_code=trust_remote_code)
    # If no pad token, set it to eos
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    # Load dataset in main process (using accelerator)
    with accelerator.main_process_first():
        dataset = load_dataset('json', data_files={
            "train": parsed_args.data_train_path,
            "validation": parsed_args.data_validation_path
        })
        
    generate_func = None
    print(parsed_args.padding)
    if parsed_args.seq2seq_or_causal == "causal":
        if parsed_args.chat_template:
            generate_func = partial(generate_and_tokenize_prompt2, tokenizer=tokenizer, max_length=parsed_args.max_length, padding=parsed_args.padding)
        else:
            generate_func = partial(generate_and_tokenize_prompt1, tokenizer=tokenizer, max_length=parsed_args.max_length, padding=parsed_args.padding)
    elif parsed_args.seq2seq_or_causal == "seq2seq":
        generate_func = partial(seq2seq_tokenize, tokenizer=tokenizer, max_length=parsed_args.max_length, padding=parsed_args.padding)
        
    # Map dataset to process with tokenizer format
    with accelerator.main_process_first():
        processed_dataset = dataset.map(generate_func, remove_columns=dataset['train'].column_names ,num_proc=8)
    
    # END DATAPROCESSING
    
    
    # 4 / 8 BIT QAT (Only optimizer) | Use Flash Attention 2
    if parsed_args.fourbit and parsed_args.eightbit:
        raise ValueError("Can not use both 4-bit and 8-bit configuration !!")
    bnb_config = None
    use_flash_attention_2 = None
    optimizer_cls = AdamW
    if parsed_args.fourbit and not parsed_args.flash_attention:
        print("Using 4-bit quantization !!")
        bnb_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16
        )
        optimizer_cls = Adam8bit
    elif parsed_args.eightbit and not parsed_args.flash_attention:
        print("Using 8-bit quantization !!")
        bnb_config = BitsAndBytesConfig(
            load_in_8bit=True,
        )
        optimizer_cls = Adam8bit
    model_hub_or_checkpoint = parsed_args.local_files_or_path
    if parsed_args.resume_from_checkpoint:
        model_hub_or_checkpoint = parsed_args.checkpoint_hub
    
    # Get specific model and data_collator to specific task ('causal', 'seq2seq')
    _model, _data_collator = model_task(parsed_args.seq2seq_or_causal)
    model = _model.from_pretrained(model_hub_or_checkpoint, 
                                                quantization_config=bnb_config, 
                                                torch_dtype=torch.bfloat16, 
                                                trust_remote_code=trust_remote_code,
                                                use_cache=False if parsed_args.gradient_checkpointing else True)
    if parsed_args.seq2seq_or_causal == "causal":
        data_collator = _data_collator(tokenizer, mlm=False)
    elif parsed_args.seq2seq_or_causal == "seq2seq":
        data_collator = _data_collator(tokenizer, model=model)
    
    # DATAPROCESSING
    # Create dataloader with data_collator relatively
    train_dataloader = DataLoader(processed_dataset['train'], shuffle=False, batch_size=parsed_args.batch_size, collate_fn=data_collator, pin_memory=False)
    eval_dataloader = DataLoader(processed_dataset['validation'], shuffle=False, batch_size=parsed_args.batch_size, collate_fn=data_collator, pin_memory=False)
    
    ## 'test_dataloader' will be designed in Benchmark Evaluation later
    test_dataloader = DataLoader(processed_dataset['validation'], shuffle=False, batch_size=parsed_args.batch_size, collate_fn=data_collator, pin_memory=False)
    # END DATAPROCESSING
    
    # MODELCONFIG
    if parsed_args.gradient_checkpointing:
        model.gradient_checkpointing_enable()
    # LoRA 2% trainable params
    if parsed_args.lora:
        print("Using LoRA !!")
        # Shut dow normal training gradient checkpointing
        gradient_checkpointing = False
        # Enable gradient checkpointing for LoRA and prepare model for LoRA
        model.gradient_checkpointing_enable()
        model = prepare_model_for_kbit_training(model)
        # Config LORA
        lora_config = LoraConfig(
            r=parsed_args.lora_rank,
            lora_alpha=16,
            target_modules=[
                "q_proj",
                "k_proj",
                "v_proj"
            ],
            bias="none",
            lora_dropout=0.05,  # Conventional
            task_type="CAUSAL_LM",
        )
        model = get_peft_model(model, lora_config)
        print(model.print_trainable_parameters())
        
    print_trainable_parameters(model)
    # END OF MODELCONFIG
    
    # Define Optimizer
    
    return model, optimizer_cls, train_dataloader, eval_dataloader, test_dataloader

def train_one_epoch(epoch: int, 
                    model: PreTrainedModel, 
                    accelerator: Accelerator, 
                    train_dataloader: DataLoader, 
                    eval_dataloader: DataLoader,
                    optimizer: Union[AdamW, Adam8bit], 
                    scheduler: Any, resume_step: int, 
                    parsed_args):
    
    train_loss = MeanMetric(nan_strategy="error").to(accelerator.device)
    for step, batch in tqdm(enumerate(train_dataloader), total=len(train_dataloader)):
        if parsed_args.resume_from_checkpoint and epoch == 0:
            if resume_step != 0 and step < resume_step:
                pass # intend to work in future. We temporarily use accelerator skip_first_batched to skip 'resume_step' of the train_dataloader
        curr_step = epoch * len(train_dataloader) + step
        model.train()
        batch.to(accelerator.device)
        outputs = model(**batch)
        loss = outputs.loss
        
        # Gather all loss before backprop in case of gradient accumulation
        loss_values = accelerator.gather_for_metrics({"loss": loss.detach().float()})
        train_loss.update(loss_values['loss'])
        
        # loss = loss / parsed_args.gradient_accumulation_steps
        accelerator.backward(loss) # get gradient norm of all params (Coi lại)
        
        if step % parsed_args.gradient_accumulation_steps == 0 or step == len(train_dataloader) - 1:
            optimizer.step()
            scheduler.step()
            optimizer.zero_grad()
        if step > 0 and (step % parsed_args.logging_train_steps == 0 or step == len(train_dataloader) - 1):
            log_train = {"train_loss": train_loss.compute()}
            accelerator.print(format_metrics(log_train, 'train', f" step {step} "))
            # Log with wanb
            accelerator.log({"training_loss": train_loss.compute()}, step=step)
            train_loss.reset()
        if step > 0 and (step % parsed_args.eval_steps == 0 or step == len(train_dataloader) - 1):
            val_loss = evaluate(model, accelerator, eval_dataloader)
            log_eval = {"val_loss": val_loss.compute()}
            accelerator.print(format_metrics(log_eval, "val", f" step {step} "))
            # Log with wanb
            accelerator.log({"validation_loss": val_loss.compute()}, step=step)
        if parsed_args.save_strategy == "step" and step > 0 and step % parsed_args.save_steps == 0:
            accelerator.save_state(f"{parsed_args.output_dir}/step_{curr_step}")
        
    return model

def train(model: PreTrainedModel, 
          accelerator: Accelerator,
          train_dataloader: DataLoader, 
          eval_dataloader: DataLoader, 
          optimizer: Union[AdamW, Adam8bit], 
          scheduler: Any, 
          num_epochs: int, 
          resume_step: int, 
          parsed_args):
    
    for epoch in range(0, num_epochs):
        
        model = train_one_epoch(epoch, model, accelerator, train_dataloader, eval_dataloader, optimizer, scheduler, resume_step, parsed_args)
        
        accelerator.print(f"Epoch {epoch} finished")
        accelerator.print(f"Pushing to HF hub")
        unwrapped_model = accelerator.unwrap_model(model)
        
        unwrapped_model.save_pretrained(
            f"{parsed_args.output_dir}/epoch_{epoch}",
            is_main_process=accelerator.is_main_process,
            save_function=accelerator.save,
            state_dict=accelerator.get_state_dict(model, unwrap=False), # FSDP: unwrap=False with save state_dict option is ShardedState
        )
            
        try:
            if accelerator.is_main_process and parsed_args.push_to_hub:
                unwrapped_model.push_to_hub(parsed_args.output_dir + f"-epoch_{epoch}", private=True)

        except Exception as e:
            accelerator.print(e)
            accelerator.print(f"Failed to push to hub")
    
    if num_epochs > 1:
        accelerator.wait_for_everyone()
        unwrapped_model = accelerator.unwrap_model(model)
        unwrapped_model.save_pretrained(
            f"{parsed_args.output_dir}/final",
            is_main_process=accelerator.is_main_process,
            save_function=accelerator.save,
            state_dict=accelerator.get_state_dict(model),
        )

    accelerator.end_training()
    return model


def pipeline(accelerator: Accelerator, parsed_args: ArgumentParser):
    
    # wandb_mode = "disabled" if not parsed_args.wandb else None
    
    # Initialise your wandb run, passing wandb parameters and any config information
    accelerator.init_trackers(
        project_name="Gemma_2b2_training",
        config=parsed_args.__dict__,
    )
    set_seed(parsed_args.seed)
    
    accelerator.print(parsed_args)
    accelerator.print(f"Using {accelerator.num_processes} GPUs")
    
    # SYSTEMCONFIG
    if parsed_args.push_to_hub:
        login(token="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", add_to_git_credential=True)
    
    model, optimizer_cls, train_dataloader, eval_dataloader, test_dataloader = data_model_config(accelerator=accelerator, parsed_args=parsed_args)
    
    # Using FSDP Mode
    # //
    # Accelerate prepare model
    model = accelerator.prepare(model) # In FSDP mode: prepare model before creating the optimizer
    optimizer = optimizer_cls(params=model.parameters(), lr=parsed_args.lr, weight_decay=parsed_args.weight_decay)
    
    num_epochs = parsed_args.num_epochs
    total_num_steps = (len(train_dataloader) * num_epochs) // parsed_args.gradient_accumulation_steps
    
    scheduler = get_scheduler(
        name="cosine",
        optimizer=optimizer,
        num_warmup_steps=parsed_args.warmup_steps,
        num_training_steps=total_num_steps,
    )
    # Accelerate prepare optimizer and the others
    optimizer, train_dataloader, eval_dataloader, scheduler = accelerator.prepare(
        optimizer, train_dataloader, eval_dataloader, scheduler
    ) # In FSDP mode: Do not prepare model with the others
    
    # Set up for resume training from checkpoint (cái này phải coi lại)
    accelerator.register_for_checkpointing(scheduler)
    
    if parsed_args.resume_from_checkpoint:
        accelerator.load_state(parsed_args.checkpoint_hub)
        accelerator.print(f"Resume from checkpoint: {parsed_args.checkpoint_hub}")
        path = os.path.basename(parsed_args.checkpoint_hub)
        training_difference = os.path.splitext(path)[0]
        if "epoch" in training_difference:
            num_epochs -= int(training_difference.replace("epoch_", ""))
            resume_step = None
        else:
            resume_step = int(training_difference.replace("step_", ""))
            num_epochs -= resume_step // len(train_dataloader)
            resume_step = (num_epochs * len(train_dataloader)) - resume_step
            train_dataloader = accelerator.skip_first_batches(train_dataloader, resume_step)
            accelerator.print(f"Resuming from step {resume_step}")
    else:
        resume_step = 0
    
    # Must waiting for muliple processes (multi gpus) handling because of asynchronous
    accelerator.wait_for_everyone()
    
    model = train(model, accelerator, train_dataloader, eval_dataloader, optimizer, scheduler, num_epochs, resume_step, parsed_args)
    
    if parsed_args.do_test:
        test(model, accelerator, test_dataloader)
    
if __name__ == "__main__":
    parser = ArgumentParser(description="Hello Mistral !!!")
    parser.add_argument("--lora", action="store_true")
    parser.add_argument("--fourbit", action="store_true")
    parser.add_argument("--eightbit", action="store_true")
    parser.add_argument("--flash_attention", action="store_true")
    parser.add_argument("--sliding_window", type=int, default=4096)
    parser.add_argument("--chat_template", action="store_true")
    parser.add_argument("--lora_rank", type=int, default=32)
    parser.add_argument("--fsdp", action="store_true")
    parser.add_argument("--gradient_accumulation_steps", type=int, default=4)
    parser.add_argument("--gradient_checkpointing", action="store_true")
    parser.add_argument("--batch_size", type=int, default=1)
    parser.add_argument("--data_train_path", type=str, default="../train_truncating2.json")
    parser.add_argument("--data_validation_path", type=str, default="../eval_truncating2.json")
    parser.add_argument("--local_files_or_path", type=str, default="mistral/")
    parser.add_argument("--dataset_cache_path", type=str, default="mapping_cache")
    parser.add_argument("--evaluation_strategy", type=str, default="no")
    parser.add_argument("--do_eval", action="store_true")
    parser.add_argument("--do_test", action="store_true")
    parser.add_argument("--eval_steps", type=int, default=600)
    parser.add_argument("--push_to_hub", action="store_true")
    parser.add_argument("--resume_from_checkpoint", action="store_true")
    parser.add_argument("--checkpoint_hub", type=str, default="kpptdll/tmp_4_12")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--lr", type=float, default=2.5e-5)
    parser.add_argument("--warmup_steps", type=int, default=0)
    parser.add_argument("--weight_decay", type=float, default=0.01)
    parser.add_argument("--num_epochs", type=int, default=2)
    parser.add_argument("--save_strategy", type=str, default="epoch")
    parser.add_argument("--save_steps", type=int, default=2)
    parser.add_argument("--output_dir", type=str, default="result_4_12")
    parser.add_argument("--logging_train_steps", type=int, default=200)
    parser.add_argument("--seq2seq_or_causal", type=str, default="causal")
    parser.add_argument("--max_length", type=int, default=2048)
    parser.add_argument("--padding", type=str, default="max_length")
    parser.add_argument("--wandb", action="store_true")
    parsed_args = parser.parse_args()
    
    if parsed_args.wandb:
#         import wandb
        # Ensure deterministic behavior for Reproducible result
        seed = parsed_args.seed
        torch.backends.cudnn.derterministic = True
        random.seed(seed)
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
#         wandb.login()
        
    fsdp_plugin = FullyShardedDataParallelPlugin(
        sharding_strategy=ShardingStrategy(1),
        state_dict_type=StateDictType(3),
        state_dict_config=ShardedStateDictConfig(offload_to_cpu=True),
        optim_state_dict_config=ShardedOptimStateDictConfig(offload_to_cpu=True),
        
    )
    print(fsdp_plugin)
    accelerator = Accelerator(fsdp_plugin=fsdp_plugin, log_with="wandb" if parsed_args.wandb else None)
    pipeline(accelerator, parsed_args)
    